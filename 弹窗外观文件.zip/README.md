# 弹窗外观相关文件

从 `EarbudsPopup` 工程里单独抽出的「外观」部分，共 8 类 59 个文件。
改这些文件就能改弹窗长什么样，不涉及电量读取、蓝牙连接、权限等逻辑。

---

## 1_弹窗卡片布局 —— 弹窗本身长什么样

| 文件 | 作用 |
|---|---|
| `popup_card.xml` | **弹窗卡片本体**（核心）。媒体区（铺满整卡的图片/GIF）+ 底部详情区（设备名、左右耳电量、充电盒电量）。改这里就是改弹窗的结构 |
| `activity_popup.xml` | 弹窗 Activity 的根布局：全屏透明 `FrameLayout`，卡片居中 |

要点：
- 卡片用自定义 `RoundedCardLayout` 承载，靠它做圆角合成，保证四角都是圆角（普通 `LinearLayout` 不裁剪子 View，铺满的图片会把圆角盖成直角）
- 详情区是 **overlay 叠在卡片底部**，不是占位留白，所以不会出现"下面空一段等文字浮上来"

## 2_弹窗渲染逻辑 —— 把数据画到卡片上

| 文件 | 作用 |
|---|---|
| `PopupRenderer.java` | **渲染核心**。绑定数据到卡片、入场/出场动画、`applyImageMatrix()` 图片缩放位移、电量文本刷新、横屏缩放（`cardScale`） |
| `RoundedCardLayout.java` | 自定义圆角容器，做框架级裁剪，保证铺满的图片不盖掉圆角 |
| `RoundedImageView.java` | 自定义圆角图片，抗锯齿离屏合成（不用系统 `clipToOutline`，那会有锯齿） |
| `LiveBlurView.java` | 详情区的实时模糊背景层 |
| `BatteryRingView.java` | 电量环形/条形指示的绘制 |

## 3_外观设置页 —— 用户可调的那些参数

| 文件 | 作用 |
|---|---|
| `tab_appearance.xml` | 「外观」页布局：弹窗图片、标题文案、宽度、圆角、图片占比、显示时长、位置、动画、配色、模糊等 |
| `Prefs.java` | **所有外观参数的读写**（整套工程共用，这里挑的是外观部分）：<br>`widthDp` 宽度 / `radiusDp` 圆角 / `imageRatio` 图片占比 / `durationMs` 时长 / `verticalPos` 垂直位置 / `animStyle` 入场动画 / `imageScale`+`imageOffsetX/Y` 图片缩放位移 / `bgColor`+`textColor`+`autoColor` 配色 / `blurRadius` 模糊 / `dimAmount` 压暗 / `landscapeScale` 横屏缩放 / `landscapeFlat` 横屏扁平度 / `enterAnimMs` 入场时长 |
| `ColorPickerView.java` | 自定义取色控件 |

注意：`MainActivity.java` 里还有外观页的滑块/开关绑定逻辑（约 2000 行，含蓝牙、电量、诊断等），没有单独抽出——如需改交互，去那个文件搜 `rowWidth`、`rowRadius`、`showSlider`。

## 4_样式与配色

| 文件 | 作用 |
|---|---|
| `colors.xml` | 全局配色（26 行）。UI 重构版的淡紫主色系 |
| `styles.xml` | 复用样式：`AppGroup` 分组卡 / `AppRow` 设置行 / `AppItem` 开关行 / `TextRowTitle·Sub·Value` 三档文字 / `AppButton` 按钮 / `TextSectionTitle` 分区标题 |
| `ids.xml` | 共享 id 定义 |

## 5_背景与图形 —— drawable 里的 `bg_*`

`bg_app` 整体渐变背景 / `bg_card` 卡片 / `bg_group` 分组 / `bg_hero` 首页头图 /
`bg_bottom_nav` 悬浮底栏 / `bg_nav_item` 导航项 / `bg_stage`+`bg_preview_stage` 预览舞台 /
`bg_battery_bar` 电量条 / `bg_chip_ok·warn` 状态标签 / `bg_glass_stroke` 描边 /
`bg_button_primary` 主按钮 / `bg_thumb` 缩略图 / `bg_shimmer` 加载微光 / `bg_accent_bar` 强调条 / `bg_header` 页头 / `bg_row_round` 圆角行 / `bg_hero_soft` 柔和头图

## 6_图标 —— drawable 里的 `ic_*`

矢量图标（25 个）：`ic_size` 尺寸 / `ic_layers` 圆角 / `ic_image` 图片 / `ic_text` 文字 /
`ic_color`+`ic_palette` 配色 / `ic_animation` 动画 / `ic_battery` 电量 / `ic_case` 充电盒 /
`ic_earbuds`+`ic_earbud_tws` 耳机 / `ic_headphone` 头戴 / `ic_preview` 预览 /
`ic_devices` 设备 / `ic_bluetooth` 蓝牙 / `ic_bolt` 快连 / `ic_lock` 锁定 /
`ic_power` 电源 / `ic_refresh` 刷新 / `ic_tune` 调节 / `ic_shield` 安全 /
`ic_info` 信息 / `ic_chevron` 箭头 / `ic_home` 首页 / `ic_notification` 通知

## 7_弹窗动画

`popup_in.xml` / `popup_out.xml`：XML 定义的补间动画。
> 注意：实际生效的是 `PopupRenderer.applyEnter()` 里用属性动画写的那套（时长由 `enterAnimMs` 控制，默认 180ms），这两个 XML 是备用。

## 8_底部导航配色

`bottom_nav_icon.xml` / `bottom_nav_text.xml`：selector，选中态紫色、未选中灰色。

---

## 常见改动对照

| 想改什么 | 改哪里 |
|---|---|
| 弹窗里显示哪些信息、排版 | `1_弹窗卡片布局/popup_card.xml` |
| 卡片宽度/圆角/图片占比默认值 | `3_外观设置页/Prefs.java` |
| 入场动画快慢 | `Prefs.enterAnimMs`（默认 180）+ `PopupRenderer.applyEnter()` |
| 横屏弹窗大小、扁平度 | `Prefs.landscapeScale` / `landscapeFlat`，生效在 `PopupActivity` 与 `PopupService` |
| 弹窗配色 | `4_样式与配色/colors.xml` + `Prefs.bgColor/textColor` |
| 圆角实现方式 | `RoundedCardLayout.java` + `RoundedImageView.java` |
| 背景模糊 | `LiveBlurView.java` + `Prefs.blurRadius` |

## 放回工程时的路径

```
1_弹窗卡片布局/*      → app/src/main/res/layout/
2_弹窗渲染逻辑/*      → app/src/main/java/com/yuanbao/earbuds/
3_外观设置页/         → tab_appearance.xml 到 res/layout/，两个 java 到 java/com/yuanbao/earbuds/
4_样式与配色/*        → app/src/main/res/values/
5_背景与图形/*        → app/src/main/res/drawable/
6_图标/*              → app/src/main/res/drawable/
7_弹窗动画/*          → app/src/main/res/anim/
8_底部导航配色/*      → app/src/main/res/color/
```
