# 补丁 1：保活增强

这是覆盖到原工程的增量补丁，不需要 Root。

## 改动
- `PopupService`：`START_STICKY` + `onTaskRemoved()` + 低频 Alarm 自恢复。
- `BootReceiver`：开机、锁屏开机、解锁、应用更新、自恢复都尝试启动服务。
- Manifest：声明 `connectedDevice` 前台服务类型。
- 新增 `KeepAliveController`：电池优化白名单引导 + Alarm 自恢复。

## ADB 建议
```bash
adb shell cmd deviceidle whitelist +com.yuanbao.earbuds
adb shell appops set com.yuanbao.earbuds RUN_IN_BACKGROUND allow
adb shell appops set com.yuanbao.earbuds RUN_ANY_IN_BACKGROUND allow
adb shell appops set com.yuanbao.earbuds SYSTEM_ALERT_WINDOW allow
```

HyperOS 的“自启动、后台活动、电池无限制”仍可能需要用户手动放行；ADB 不能保证绕过厂商策略。

## 说明
15 分钟级 Alarm 只是恢复兜底，不是高频轮询。这样做比每几秒强行拉活更省电，也更符合 Android 的后台模型。
