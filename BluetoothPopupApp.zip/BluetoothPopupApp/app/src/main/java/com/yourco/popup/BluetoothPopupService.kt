package com.yourco.popup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * 前台服务：监听蓝牙连接广播，连接瞬间启动弹窗并探测电量。
 * 依赖 ADB 后台白名单（见 adb_setup.sh），否则国产 ROM 可能杀后台。
 */
class BluetoothPopupService : Service() {

    override fun onCreate() {
        super.onCreate()
        BatteryEngine.init(this)
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(aclReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(aclReceiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val type = if (Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(aclReceiver)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private val aclReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val device = deviceOf(intent) ?: return
            when (intent.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    val cached = BatteryEngine.batteryOf(device)
                    showPopup(device, cached)
                    // 还没拿到电量：异步探测，弹窗页通过 listener 实时刷新
                    if (cached < 0) BatteryEngine.probe(device) {}
                }
                BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED -> {
                    // 已由 BatteryEngine 的接收器处理并回调 listener
                }
            }
        }
    }

    private fun showPopup(device: BluetoothDevice, battery: Int) {
        val name = device.name ?: device.address
        val i = Intent(this, PopupActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("device_name", name)
            putExtra("device_address", device.address)
            putExtra("battery", battery)
        }
        startActivity(i)
    }

    private fun deviceOf(i: Intent): BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
        i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
    else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private fun buildNotification(): Notification {
        val chId = "bluetooth_popup_channel"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "蓝牙弹窗", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(this, chId)
            .setContentTitle("蓝牙弹窗运行中")
            .setContentText("连接蓝牙耳机时自动弹出电量")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 1001
        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, BluetoothPopupService::class.java))
        }
    }
}
