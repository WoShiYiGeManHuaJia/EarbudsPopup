package com.yourco.popup

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

/**
 * 弹窗页：显示自定义图片/GIF + 设备名 + 真实电量，约 3.5 秒后自动关闭。
 * 若电量尚未拿到，先显示"读取中…"，探测完成后通过 BatteryEngine.listener 实时刷新。
 */
class PopupActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private var address: String? = null
    private lateinit var tvBattery: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.popup_layout)
        SettingsStore.init(this)

        val name = intent.getStringExtra("device_name") ?: "蓝牙设备"
        address = intent.getStringExtra("device_address")
        val battery = intent.getIntExtra("battery", -1)

        tvBattery = findViewById(R.id.tv_battery)
        findViewById<TextView>(R.id.tv_name).text = name

        val iv = findViewById<ImageView>(R.id.iv_popup)
        val uri = SettingsStore.imageUri
        if (uri != null) {
            Glide.with(this).load(uri).into(iv)   // 自动识别 GIF / 静态图
        } else {
            iv.setImageResource(android.R.drawable.ic_btn_speak_now)
        }

        updateBattery(battery)

        // 异步探测结果的实时刷新
        BatteryEngine.listener = { addr, lvl ->
            main.post { if (addr == address && lvl in 0..100) updateBattery(lvl) }
        }

        // 3.5 秒后自动关闭
        main.postDelayed({ finish() }, 3500)
    }

    override fun onDestroy() {
        BatteryEngine.listener = null
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun updateBattery(level: Int) {
        tvBattery.text = if (level in 0..100) "$level%" else "电量读取中…"
    }
}
