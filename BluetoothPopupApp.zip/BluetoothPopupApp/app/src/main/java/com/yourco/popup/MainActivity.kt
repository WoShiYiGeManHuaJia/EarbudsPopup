package com.yourco.popup

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide

/**
 * 主界面：选择弹窗图片/GIF、申请权限、启动后台服务。
 */
class MainActivity : AppCompatActivity() {

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            SettingsStore.imageUri = uri.toString()
            loadPreview(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        SettingsStore.init(this)

        findViewById<Button>(R.id.btn_pick).setOnClickListener {
            pickImage.launch(arrayOf("image/*"))
        }

        findViewById<Button>(R.id.btn_start).setOnClickListener {
            if (hasBtPerm()) {
                BluetoothPopupService.start(this)
                Toast.makeText(this, "服务已启动", Toast.LENGTH_SHORT).show()
            } else {
                requestPermissions(btPerms(), 1001)
                Toast.makeText(this, "请授权蓝牙权限后再次点击", Toast.LENGTH_SHORT).show()
            }
        }

        SettingsStore.imageUri?.let { loadPreview(Uri.parse(it)) }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && hasBtPerm()) {
            BluetoothPopupService.start(this)
            Toast.makeText(this, "服务已启动", Toast.LENGTH_SHORT).show()
        }
    }

    private fun btPerms(): Array<String> = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    else arrayOf(Manifest.permission.BLUETOOTH)

    private fun hasBtPerm(): Boolean = btPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadPreview(uri: Uri) {
        Glide.with(this).load(uri).into(findViewById<ImageView>(R.id.iv_preview))
    }
}
