package com.yourco.popup

import android.content.Context
import android.content.SharedPreferences

/** 持久化用户设置（弹窗图片/GIF 的 URI 等） */
object SettingsStore {
    private lateinit var prefs: SharedPreferences
    private const val KEY_IMAGE = "popup_image_uri"

    var imageUri: String?
        get() = prefs.getString(KEY_IMAGE, null)
        set(v) { prefs.edit().putString(KEY_IMAGE, v).apply() }

    fun init(c: Context) {
        if (::prefs.isInitialized) return
        prefs = c.getSharedPreferences("popup_cfg", Context.MODE_PRIVATE)
    }
}
