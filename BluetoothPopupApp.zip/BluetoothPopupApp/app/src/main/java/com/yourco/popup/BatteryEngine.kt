package com.yourco.popup

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * 最大化兼容的蓝牙耳机电量探测引擎（非 root / 非系统应用）。
 *
 * 探测路径（按序取第一个成功值）：
 *   Path 1  系统框架电量：getBatteryLevel + ACTION_BATTERY_LEVEL_CHANGED 广播
 *           （在小米/OPPO/vivo/华为等国产 ROM 上覆盖很广）
 *   Path 2  标准 Battery Service GATT 读：0x180F / 0x2A19
 *   Path 3  （扩展槽）厂商私有 GATT 服务：按机型白名单逐步补充
 *
 * 三条都失败 → 返回 -1，调用方应降级显示，禁止伪造电量。
 */
object BatteryEngine {
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val cache = ConcurrentHashMap<String, Int>()          // address -> level
    private val pendingGatt = ConcurrentHashMap<String, Boolean>()

    /** 弹窗实时更新回调：level 为 0..100 真电量，-1 表示拿不到 */
    var listener: ((address: String, level: Int) -> Unit)? = null

    private val BT_BATTERY_SVC = UUID.fromString("0000180F-0000-1000-8000-00805F9B34FB")
    private val BT_BATTERY_CHAR = UUID.fromString("00002A19-0000-1000-8000-00805F9B34FB")

    // 系统电量广播：一旦系统解析出电量，被动拿到真值
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED) return
            val d = deviceOf(i) ?: return
            val lvl = i.getIntExtra(BluetoothDevice.EXTRA_BATTERY_LEVEL, -1)
            if (lvl in 0..100) { cache[d.address] = lvl; emit(d.address, lvl) }
        }
    }

    fun init(context: Context) {
        if (::app.isInitialized) return
        app = context.applicationContext
        val f = IntentFilter(BluetoothDevice.ACTION_BATTERY_LEVEL_CHANGED)
        if (Build.VERSION.SDK_INT >= 33)
            app.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else app.registerReceiver(receiver, f)
    }

    /** 同步拿缓存/系统电量；拿不到返回 -1（此时可触发异步 probe） */
    fun batteryOf(device: BluetoothDevice): Int {
        cache[device.address]?.let { return it }
        if (hasPerm()) readSystemLevel(device)?.let { cache[device.address] = it; return it }
        return -1
    }

    /** 完整异步探测：Path1 系统 → Path2 GATT，结果回调（0..100 真电量，-1 拿不到） */
    fun probe(device: BluetoothDevice, onResult: (Int) -> Unit) {
        if (!hasPerm()) { onResult(-1); return }
        if (pendingGatt[device.address] == true) return
        readSystemLevel(device)?.let { cache[device.address] = it; onResult(it); return }
        pendingGatt[device.address] = true
        readGattBattery(device) { lvl ->
            pendingGatt[device.address] = false
            if (lvl in 0..100) cache[device.address] = lvl
            onResult(lvl)
        }
    }

    // ---------- Path 1：系统框架 ----------
    private fun readSystemLevel(d: BluetoothDevice): Int? = try {
        val lvl = if (Build.VERSION.SDK_INT >= 31) d.getBatteryLevel()
                  else @Suppress("DEPRECATION") d.batteryLevel
        if (lvl in 0..100) lvl else null
    } catch (_: SecurityException) { null }

    // ---------- Path 2：GATT 标准电池服务 ----------
    private fun readGattBattery(device: BluetoothDevice, cb: (Int) -> Unit) {
        var gatt: BluetoothGatt? = null
        val timeout = Runnable {
            gatt?.disconnect(); gatt?.close(); cb(-1)
        }
        val gattCb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt?, status: Int, ns: Int) {
                when (ns) {
                    BluetoothProfile.STATE_CONNECTED -> g?.discoverServices()
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        main.removeCallbacks(timeout); cb(-1)
                    }
                }
            }
            override fun onServicesDiscovered(g: BluetoothGatt?, status: Int) {
                val ch = g?.getService(BT_BATTERY_SVC)?.getCharacteristic(BT_BATTERY_CHAR)
                if (ch != null) {
                    main.removeCallbacks(timeout)
                    g!!.readCharacteristic(ch)
                    main.postDelayed(timeout, 2000)
                } else {
                    g?.disconnect(); g?.close(); cb(-1)
                }
            }
            override fun onCharacteristicRead(
                g: BluetoothGatt?, c: BluetoothGattCharacteristic?, status: Int
            ) {
                main.removeCallbacks(timeout)
                val lvl = if (status == BluetoothGatt.GATT_SUCCESS && c != null)
                    c.value.firstOrNull()?.toInt() ?: -1 else -1
                g?.disconnect(); g?.close()
                cb(lvl)
            }
        }
        gatt = try {
            if (Build.VERSION.SDK_INT >= 31)
                device.connectGatt(app, false, gattCb, BluetoothDevice.TRANSPORT_AUTO)
            else @Suppress("DEPRECATION") device.connectGatt(app, false, gattCb)
        } catch (_: SecurityException) { null }
        if (gatt == null) cb(-1) else main.postDelayed(timeout, 4000)
    }

    // ---------- 工具 ----------
    private fun deviceOf(i: Intent): BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
        i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
    else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private fun hasPerm(): Boolean = when {
        Build.VERSION.SDK_INT >= 31 ->
            app.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            app.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        else -> app.checkSelfPermission(Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
    }

    private fun emit(a: String, l: Int) = listener?.invoke(a, l)
}
