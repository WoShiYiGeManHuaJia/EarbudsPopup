package com.yourco.popup

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 开机自启：重启后自动拉起后台弹窗服务 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            BluetoothPopupService.start(context)
        }
    }
}
