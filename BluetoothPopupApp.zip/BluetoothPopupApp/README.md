# 蓝牙弹窗 APP（BluetoothPopup）

自定义蓝牙耳机连接弹窗（图片/GIF + **真实电量**）。Android 12+，非 root，配合 ADB 使用。

## 能做什么

- 连接蓝牙耳机时弹出你自定义的图片或 GIF。
- 显示**真实电量**（不是假数据）。
- 后台保活：配合 ADB 脚本防杀后台，连接瞬间稳定弹出。

## 电量怎么拿到的（核心逻辑）

三条路径按序取第一个成功值，全部失败则显示"读取中…"（不伪造）：

| 路径 | 机制 | 适用 |
|---|---|---|
| Path 1 | 系统框架电量：`getBatteryLevel()` + `ACTION_BATTERY_LEVEL_CHANGED` 广播 | 国产 ROM（小米/OPPO/vivo/华为等）覆盖广 |
| Path 2 | GATT 主动读标准 Battery Service `0x180F` / `0x2A19` | 暴露标准电池服务的耳机 |
| 降级 | 都失败 → 返回 -1，UI 显示"电量读取中…" | 只走厂商私有协议的耳机 |

**诚实边界**：对既无系统解析、又不暴露 0x180F 的耳机，非 root 的第三方应用拿不到真电量——这是 Android 平台限制，不是代码问题。任何声称"任何耳机都绝对真电量"的方案都是假的。

## 工程结构

```
app/src/main/java/com/yourco/popup/
├── MainActivity.kt          主界面：选图、授权、启动服务
├── BatteryEngine.kt         电量探测引擎（核心，三条路径）
├── BluetoothPopupService.kt 前台服务：监听连接、保持存活
├── PopupActivity.kt         弹窗页：显示图片/GIF + 电量，3.5s 自动关
├── BootReceiver.kt          开机自启
└── SettingsStore.kt         设置存储
```

## 构建

用 Android Studio 打开本项目，`Sync` 后 Build 即可（AGP 8.2.2 / Kotlin 1.9.22 / minSdk 31 / targetSdk 34）。也可命令行：

```bash
./gradlew assembleDebug   # 产物：app/build/outputs/apk/debug/app-debug.apk
```

## 装机

1. 安装 APK。
2. 手机开 USB 调试并连接电脑，运行 `./adb_setup.sh`（预授权蓝牙权限 + 后台白名单）。
3. 详见 `setup_instructions.md`。

## 备注

- 弹窗采用「独立任务 + 透明主题的 Activity」实现，无需"悬浮窗"权限，在 Android 12 上更稳。
- 若想弹窗盖住所有应用（含全屏），可改用 `TYPE_APPLICATION_OVERLAY`，需申请 `SYSTEM_ALERT_WINDOW`（"显示在其他应用上层"），属进阶改造。
