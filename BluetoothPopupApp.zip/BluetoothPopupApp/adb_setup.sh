#!/usr/bin/env bash
# 蓝牙弹窗 APP —— 一键装机脚本（无需 root，只需 ADB）
# 用法：手机打开"开发者选项 + USB 调试"→ USB 连接电脑 → 运行 ./adb_setup.sh
# 如果包名改过，把下面的 PKG 换成你的 applicationId。
set -e
PKG="com.yourco.popup"

echo "================================================"
echo " 蓝牙弹窗 APP 装机脚本"
echo "================================================"

# 检查 adb 是否可用
if ! command -v adb >/dev/null 2>&1; then
    echo "[错误] 找不到 adb，请先安装 platform-tools 并加入 PATH。"
    exit 1
fi

# 检查设备
if ! adb devices | grep -qw device; then
    echo "[错误] 未检测到已连接的手机。请开启 USB 调试后重试。"
    adb devices
    exit 1
fi

echo "[1/4] 检查 APP 是否已安装..."
adb shell pm path "$PKG" >/dev/null 2>&1 || {
    echo "[错误] 未安装 $PKG，请先安装 APK。"
    exit 1
}

echo "[2/4] 预授权 Android 12 蓝牙运行时权限（免手动授权）..."
adb shell pm grant "$PKG" android.permission.BLUETOOTH_CONNECT || echo "  (BLUETOOTH_CONNECT 授权失败，可忽略)"
adb shell pm grant "$PKG" android.permission.BLUETOOTH_SCAN || echo "  (BLUETOOTH_SCAN 授权失败，可忽略)"

echo "[3/4] 后台白名单（防杀后台，弹窗存活的关键）..."
adb shell appops set "$PKG" AUTO_START allow || echo "  (AUTO_START 失败，可忽略)"
adb shell appops set "$PKG" RUN_IN_BACKGROUND allow || echo "  (RUN_IN_BACKGROUND 失败，可忽略)"
adb shell appops set "$PKG" START_FOREGROUND allow || echo "  (START_FOREGROUND 失败，可忽略)"
adb shell dumpsys deviceidle whitelist "+$PKG" || echo "  (deviceidle 白名单失败，可忽略)"

echo "[4/4] 完成！"
echo "----------------------------------------------"
echo " 诊断某耳机是否有系统电量（决定能否拿到真电量）："
echo "   adb shell dumpsys bluetooth_manager | grep -iE 'Address:|BatteryLevel|mBatteryLevel'"
echo "----------------------------------------------"
