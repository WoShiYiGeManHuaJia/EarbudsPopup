package com.earpopupx;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.PackageManager;
import java.lang.reflect.Method;
import java.util.UUID;

/** Reads only values actually supplied by Android/vendor Bluetooth. Never invents battery percentages. */
public final class BluetoothBatteryReader {
    public interface Callback { void onState(BatteryState state); }
    private static final UUID BATTERY_SERVICE = UUID.fromString("0000180F-0000-1000-8000-00805F9B34FB");
    private static final UUID BATTERY_LEVEL = UUID.fromString("00002A19-0000-1000-8000-00805F9B34FB");
    private final Context context;
    public BluetoothBatteryReader(Context c) { context=c.getApplicationContext(); }

    public void read(BluetoothDevice d, Callback cb) {
        int level = getSystemLevel(d);
        if (level >= 0) { cb.onState(new BatteryState(level,-1,-1,-1,false,false,false,"Android Bluetooth")); return; }
        if (android.os.Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            cb.onState(BatteryState.unknown("无 BLUETOOTH_CONNECT 权限")); return;
        }
        try {
            d.connectGatt(context, true, new BluetoothGattCallback() {
                @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        try { g.discoverServices(); } catch (Throwable ignored) {}
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) { try { g.close(); } catch (Throwable ignored) {} }
                }
                @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
                    try {
                        android.bluetooth.BluetoothGattService s = g.getService(BATTERY_SERVICE);
                        BluetoothGattCharacteristic c = s == null ? null : s.getCharacteristic(BATTERY_LEVEL);
                        if (c != null && g.readCharacteristic(c)) return;
                    } catch (Throwable ignored) {}
                    cb.onState(BatteryState.unknown("Bluetooth Battery Service unavailable"));
                    try { g.disconnect(); } catch (Throwable ignored) {}
                }
                @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
                    if (status == BluetoothGatt.GATT_SUCCESS && BATTERY_LEVEL.equals(c.getUuid())) {
                        int v = c.getValue() == null || c.getValue().length == 0 ? -1 : (c.getValue()[0] & 0xff);
                        cb.onState(new BatteryState(v,-1,-1,-1,false,false,false,"BLE Battery Service"));
                    } else cb.onState(BatteryState.unknown("BLE read failed"));
                    try { g.disconnect(); } catch (Throwable ignored) {}
                }
            }, false);
        } catch (Throwable t) { cb.onState(BatteryState.unknown("Bluetooth read unavailable")); }
    }

    private int getSystemLevel(BluetoothDevice d) {
        try {
            Method m = BluetoothDevice.class.getMethod("getBatteryLevel");
            Object r = m.invoke(d);
            if (r instanceof Integer) { int v=(Integer)r; if (v>=0 && v<=100) return v; }
        } catch (Throwable ignored) {}
        return -1;
    }
}
