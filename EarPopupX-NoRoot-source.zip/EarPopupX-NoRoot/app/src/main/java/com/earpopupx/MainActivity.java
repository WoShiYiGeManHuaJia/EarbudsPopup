package com.earpopupx;

import android.Manifest; import android.app.*; import android.bluetooth.BluetoothAdapter; import android.content.*; import android.content.pm.PackageManager; import android.net.Uri; import android.os.*; import android.provider.Settings; import android.view.View; import android.widget.*; import java.util.*;

public final class MainActivity extends Activity {
    private static final int REQ_BT=10, REQ_NOTIFY=11, REQ_MEDIA=12;
    private TextView status;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main); bind(); updateStatus(); }
    private void bind(){
        status=findViewById(R.id.status);
        findViewById(R.id.overlay).setOnClickListener(v->openOverlay());
        findViewById(R.id.notifications).setOnClickListener(v->requestNotifications());
        findViewById(R.id.bluetooth).setOnClickListener(v->requestBluetooth());
        findViewById(R.id.battery).setOnClickListener(v->{ try{startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:"+getPackageName())));}catch(Throwable t){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));} });
        findViewById(R.id.start).setOnClickListener(v->startMonitor());
        findViewById(R.id.test).setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){openOverlay(); return;} new EarPopupWindow(this).show("测试耳机",BatteryState.unknown("测试：未伪造电量")); });
        findViewById(R.id.pick).setOnClickListener(v->pickMedia());
        findViewById(R.id.reset).setOnClickListener(v->{AppPrefs.setMedia(this,null);Toast.makeText(this,"已恢复默认",Toast.LENGTH_SHORT).show();});
    }
    private void openOverlay(){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))); }
    private void requestBluetooth(){ if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT); }
    private void requestNotifications(){ if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFY); }
    private void pickMedia(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,REQ_MEDIA); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==REQ_MEDIA&&c==RESULT_OK&&d!=null&&d.getData()!=null){ try{getContentResolver().takePersistableUriPermission(d.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Throwable ignored){} AppPrefs.setMedia(this,d.getData()); Toast.makeText(this,"图片/GIF已保存",Toast.LENGTH_SHORT).show(); } }
    private void startMonitor(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestBluetooth();return;}
        if(!Settings.canDrawOverlays(this)){openOverlay();return;}
        Intent i=new Intent(this,BluetoothMonitorService.class); try{if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"耳机监听已启动",Toast.LENGTH_SHORT).show();}catch(Throwable t){Toast.makeText(this,"启动失败：请保持本页面打开后再试",Toast.LENGTH_LONG).show();}
    }
    private void updateStatus(){
        StringBuilder s=new StringBuilder(); s.append("当前状态
"); s.append(Settings.canDrawOverlays(this)?"✓ 悬浮窗：已授权
":"✗ 悬浮窗：未授权
"); if(Build.VERSION.SDK_INT>=31)s.append(checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED?"✓ 蓝牙：已授权
":"✗ 蓝牙：未授权
"); if(Build.VERSION.SDK_INT>=33)s.append(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED?"✓ 通知：已授权
":"✗ 通知：未授权
"); status.setText(s.toString());
    }
    @Override protected void onResume(){super.onResume();updateStatus();}
}
