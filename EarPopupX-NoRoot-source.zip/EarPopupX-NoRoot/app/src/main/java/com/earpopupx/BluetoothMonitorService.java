package com.earpopupx;

import android.Manifest;
import android.app.*; import android.content.pm.ServiceInfo;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import java.util.HashSet;
import java.util.Set;

public final class BluetoothMonitorService extends Service {
    private static final String CHANNEL="earpopupx_monitor";
    private BluetoothBatteryReader reader; private EarPopupWindow popup; private BroadcastReceiver receiver; private final Set<String> shown=new HashSet<>();
    @Override public void onCreate(){ super.onCreate(); createChannel(); reader=new BluetoothBatteryReader(this); popup=new EarPopupWindow(this); register(); }
    @Override public int onStartCommand(Intent i,int flags,int id){ startAsForeground(); return START_STICKY; }
    private void startAsForeground(){
        Notification n;
        if(Build.VERSION.SDK_INT>=26) n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setContentTitle("EarPopup X").setContentText("正在监听蓝牙耳机连接").setOngoing(true).build();
        else n=new Notification.Builder(this).setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setContentTitle("EarPopup X").setContentText("正在监听蓝牙耳机连接").setOngoing(true).build();
        try { if(Build.VERSION.SDK_INT>=29) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE); else startForeground(7,n); } catch(Throwable t){ startForeground(7,n); }
    }
    private void register(){
        receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){ String a=i.getAction(); if(BluetoothDevice.ACTION_ACL_CONNECTED.equals(a)){ BluetoothDevice d=getDevice(i); if(d!=null) handle(d,true); } else if(BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(a)){ BluetoothDevice d=getDevice(i); if(d!=null) shown.remove(d.getAddress()); popup.dismiss(); } else if("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED".equals(a)){ BluetoothDevice d=getDevice(i); if(d!=null){ int v=i.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL",-1); if(v>=0&&v<=100) popup.show(safeName(d),new BatteryState(v,-1,-1,-1,false,false,false,"系统蓝牙广播")); } } }};
        IntentFilter f=new IntentFilter(); f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED); f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED); f.addAction("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED");
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
    }
    private void handle(BluetoothDevice d,boolean show){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) return;
        String addr; try{addr=d.getAddress();}catch(Throwable t){return;} if(shown.contains(addr)) return; shown.add(addr);
        reader.read(d,s-> { if(AppPrefs.enabled(this)&&show) popup.show(safeName(d),s); });
    }
    private BluetoothDevice getDevice(Intent i){ try { if(Build.VERSION.SDK_INT>=33) return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE,BluetoothDevice.class); return (BluetoothDevice)i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); }catch(Throwable t){return null;} }
    private String safeName(BluetoothDevice d){ try{return d.getName()==null?"蓝牙耳机":d.getName();}catch(Throwable t){return "蓝牙耳机";} }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL,"耳机连接监控",NotificationManager.IMPORTANCE_LOW)); } }
    @Override public void onDestroy(){ try{unregisterReceiver(receiver);}catch(Throwable ignored){} if(popup!=null)popup.dismiss(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
