package com.earpopupx;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;

public final class EarPopupWindow {
    private final Context context;
    private WindowManager wm;
    private View root;
    private final Handler handler = new Handler(Looper.getMainLooper());
    public EarPopupWindow(Context c) { context=c.getApplicationContext(); }

    public void show(String name, BatteryState state) {
        if (!Settings.canDrawOverlays(context)) return;
        dismiss();
        wm=(WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
        LinearLayout card=new LinearLayout(context); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_HORIZONTAL); card.setPadding(dp(26),dp(24),dp(26),dp(24));
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.argb(224,250,250,250)); bg.setCornerRadius(dp(34)); card.setBackground(bg);

        ImageView media=new ImageView(context); media.setScaleType(ImageView.ScaleType.CENTER_CROP); loadMedia(media); card.addView(media,new LinearLayout.LayoutParams(-1,dp(300)));
        TextView title=text(name,28,true); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER); card.addView(title,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView battery=text(formatBattery(state),18,false); battery.setTextColor(Color.rgb(35,35,35)); battery.setGravity(Gravity.CENTER); battery.setPadding(0,dp(8),0,dp(8)); card.addView(battery,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView source=text("数据来源："+state.source,11,false); source.setTextColor(Color.DKGRAY); source.setGravity(Gravity.CENTER); card.addView(source,new LinearLayout.LayoutParams(-1,dp(30)));
        root=card;

        WindowManager.LayoutParams lp=new WindowManager.LayoutParams();
        lp.width=(int)(getWidth()*0.94f); lp.height=dp(500); lp.gravity=Gravity.CENTER;
        lp.type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        lp.format=android.graphics.PixelFormat.TRANSLUCENT;
        lp.flags=WindowManager.LayoutParams.FLAG_DIM_BEHIND | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        lp.dimAmount=0.12f;
        lp.windowAnimations=android.R.style.Animation_Dialog;
        if (Build.VERSION.SDK_INT>=31) {
            try { lp.setBlurBehindRadius(dp(34)); lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND; } catch(Throwable ignored) {}
        }
        try { wm.addView(root,lp); animateIn(root); handler.postDelayed(this::dismiss, 6500L); } catch(Throwable ignored) { root=null; }
    }
    private void animateIn(View v){ v.setAlpha(0f); v.setScaleX(.94f); v.setScaleY(.94f); AnimatorSet s=new AnimatorSet(); s.playTogether(ObjectAnimator.ofFloat(v,"alpha",0f,1f),ObjectAnimator.ofFloat(v,"scaleX",.94f,1f),ObjectAnimator.ofFloat(v,"scaleY",.94f,1f)); s.setDuration(260); s.start(); }
    public void dismiss(){ handler.removeCallbacksAndMessages(null); if(wm!=null&&root!=null){try{wm.removeView(root);}catch(Throwable ignored){} root=null;} }
    private TextView text(String s,int size,boolean bold){ TextView t=new TextView(context); t.setText(s); t.setTextSize(size); t.setTypeface(null,bold?1:0); return t; }
    private String formatBattery(BatteryState s){
        String a = s.aggregate>=0 ? "电量  "+s.aggregate+"%" : "电量  未知";
        String l = s.left>=0 ? "左耳 "+s.left+"%" : "左耳 未知";
        String r = s.right>=0 ? "右耳 "+s.right+"%" : "右耳 未知";
        String c = s.caseLevel>=0 ? "盒子 "+s.caseLevel+"%" : "盒子 未知";
        if(s.left<0&&s.right<0&&s.caseLevel<0) return a;
        return l+"    "+r+"    "+c;
    }
    private void loadMedia(ImageView v){
        String raw=AppPrefs.media(context); if(raw==null) return;
        try {
            Uri u=Uri.parse(raw); ImageDecoder.Source src=ImageDecoder.createSource(context.getContentResolver(),u); Drawable d=ImageDecoder.decodeDrawable(src); v.setImageDrawable(d); if(d instanceof AnimatedImageDrawable) ((AnimatedImageDrawable)d).start();
        } catch(Throwable ignored) {}
    }
    private int dp(int n){ return (int)(n*context.getResources().getDisplayMetrics().density+.5f); }
    private int getWidth(){ return context.getResources().getDisplayMetrics().widthPixels; }
}
