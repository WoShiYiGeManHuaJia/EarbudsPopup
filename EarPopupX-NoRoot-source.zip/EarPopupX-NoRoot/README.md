# EarPopup X — No Root

针对 Redmi K70 Pro / HyperOS 的无 Root 蓝牙耳机弹窗工程。

## 已实现
- 无 Root，普通 APK + SYSTEM_ALERT_WINDOW Overlay
- 蓝牙 ACL 连接自动触发弹窗
- 图片/GIF 从系统文件选择器导入并持久保存（GIF 原帧动画播放）
- Android 12+ 窗口后景模糊（设备支持时）+ 大圆角玻璃卡片
- 自定义图片/GIF使用 ImageDecoder；GIF 使用 AnimatedImageDrawable 持续播放
- Android 蓝牙系统电量反射读取（如果设备 ROM 暴露 getBatteryLevel）
- 标准 BLE Battery Service 0x180F / 0x2A19 回退读取
- 无法可靠读取时显示“未知”，不伪造电量
- Foreground Service / connectedDevice
- 开机恢复、ACL_CONNECTED 触发恢复
- ADB 辅助脚本：overlay AppOps、Doze whitelist、后台 AppOps

## 重要限制
普通 APK 无 Root / 系统签名不能进入 Xiaomi SystemUI 或 com.xiaomi.bluetooth 内部，因此本工程不是 LSPosed 系统 Hook。它提供尽可能接近 HyperOS 的系统级视觉体验。

“左耳/右耳/盒子”独立电量只有在耳机通过 Android/标准 BLE/厂商协议实际暴露这些字段时才能显示。当前通用层不会猜测或伪造三个数字。要支持某一型号的私有协议，应新增 VendorAdapter。

## 编译
用 Android Studio 打开本目录，Gradle JDK 17，Android Gradle Plugin 8.13.0，compileSdk 35，minSdk 29。

## 首次运行
1. 安装 APK。
2. 授予蓝牙权限。
3. 授予悬浮窗权限。
4. Android 13+ 授予通知权限。
5. 建议关闭电池优化。
6. 点“启动耳机监听”。
7. 需要增强后台权限时，在电脑执行 adb/enable_protection.bat（Windows）或 adb/enable_protection.sh（macOS/Linux）。
8. HyperOS 若有“自启动/电池”策略，请把 EarPopup X 加入允许名单。

## 关于真正的 HyperOS 原生 Focus Island
公开项目证明，真正的 Focus Island 耳机弹窗通常通过 Root + LSPosed Hook com.android.bluetooth / com.milink.service / com.xiaomi.bluetooth 等私有链路完成。本工程刻意不依赖这些组件，因为用户设备没有 Root。
