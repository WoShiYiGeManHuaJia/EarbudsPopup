# EarPopup X — No Root v1.1

针对 Redmi K70 Pro / HyperOS 的无 Root 蓝牙耳机弹窗工程。

## 本次修复
- 修复“连接耳机没有弹窗”：ACL_CONNECTED 到达后**立即显示弹窗**，先显示“正在读取电量…”，随后由系统蓝牙电量广播 / BLE Battery Service 更新真实电量。
- 修复测试弹窗没有关闭按钮：右上角增加明确关闭按钮。
- 重做主页面：状态卡片、权限卡片、素材卡片、弹窗调试卡片，减少传统 Button 堆叠感。
- 图片/GIF 自动裁切为圆角；GIF 继续逐帧播放。
- 增加 X/Y 位置、宽高、圆角、模糊、背景压暗、显示时长调节。
- 增加“测试弹窗可拖动定位”：打开后，测试弹窗可以直接拖动；松手自动保存 X/Y。
- 修复连接监听只在服务启动后才工作的体验：主页面启动监听后即可持续监听；开机/ACL 事件仍会尝试恢复服务。
- ADB 脚本增加 Bluetooth/通知 runtime grant、Overlay AppOp、Doze 白名单、后台 AppOps 和重启。

## 真实电量原则
不生成随机电量，不把上一副耳机电量套给下一副耳机。

读取来源：
1. 系统 Bluetooth Battery Level 广播（如果 ROM/耳机提供）。
2. Android 蓝牙栈可读取的设备电量（ROM 暴露时）。
3. 标准 BLE Battery Service 0x180F / 0x2A19。

左右耳/盒子独立电量不是 Android 的统一通用 API。没有可靠来源就显示“—”，不会伪造。

## ADB 能做到什么
`adb/enable_protection.bat` 和 `adb/enable_protection.sh` 会尝试：
- `SYSTEM_ALERT_WINDOW` AppOp = allow
- `BLUETOOTH_CONNECT / BLUETOOTH_SCAN` runtime grant
- `POST_NOTIFICATIONS` runtime grant
- Doze whitelist
- `RUN_IN_BACKGROUND / RUN_ANY_IN_BACKGROUND`
- 重启 App

ADB **不能**把普通 APK 变成 `com.android.systemui` / `com.xiaomi.bluetooth` 的系统签名组件，也不能在无 Root/无系统签名时直接修改 Xiaomi Focus Island 内部 View。

## 首次使用
1. 安装 APK。
2. 运行 App，授予蓝牙权限和悬浮窗权限。
3. Android 13+ 授予通知权限。
4. 点“启动耳机监听”。
5. 可连接耳机测试；连接事件会立即弹窗，电量后到时会更新。
6. 建议在 HyperOS 开启 EarPopup X 自启动、后台无限制。
7. 如果有电脑，可运行 `adb/enable_protection.bat` / `.sh`。

## 弹窗调试
- X / Y：直接调整中心偏移。
- 宽度：84%~100%。
- 高度：380~800dp。
- 圆角：0~60dp。
- 模糊：0~80dp（设备支持跨窗口模糊时生效）。
- 背景压暗：0~35%。
- 显示时长：2~20秒。
- 打开“测试弹窗可拖动定位”后，测试弹窗可直接拖到目标位置，松手保存坐标。
- 右上角 X 始终可以关闭测试/连接弹窗。

## 编译
Android Studio / JDK 17 / AGP 8.13.0 / compileSdk 35 / minSdk 29 / targetSdk 35。
