package com.earpopupx;

import android.content.Context;
import android.net.Uri;

public final class AppPrefs {
    private static final String P = "earpopupx";
    private static final String KEY_MEDIA = "media";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_X = "x";
    private static final String KEY_Y = "y";
    private static final String KEY_WIDTH = "width";
    private static final String KEY_HEIGHT = "height";
    private static final String KEY_RADIUS = "radius";
    private static final String KEY_BLUR = "blur";
    private static final String KEY_DIM = "dim";
    private static final String KEY_DURATION = "duration";
    private static final String KEY_DRAG = "drag";

    private static android.content.SharedPreferences p(Context c) { return c.getSharedPreferences(P, Context.MODE_PRIVATE); }
    public static String media(Context c) { return p(c).getString(KEY_MEDIA, null); }
    public static void setMedia(Context c, Uri u) { p(c).edit().putString(KEY_MEDIA, u == null ? null : u.toString()).apply(); }
    public static boolean enabled(Context c) { return p(c).getBoolean(KEY_ENABLED, true); }
    public static void setEnabled(Context c, boolean v) { p(c).edit().putBoolean(KEY_ENABLED, v).apply(); }
    public static int x(Context c) { return p(c).getInt(KEY_X, 0); }
    public static int y(Context c) { return p(c).getInt(KEY_Y, 0); }
    public static int widthPercent(Context c) { return p(c).getInt(KEY_WIDTH, 94); }
    public static int heightDp(Context c) { return p(c).getInt(KEY_HEIGHT, 520); }
    public static int radiusDp(Context c) { return p(c).getInt(KEY_RADIUS, 34); }
    public static int blurDp(Context c) { return p(c).getInt(KEY_BLUR, 34); }
    public static int dimPercent(Context c) { return p(c).getInt(KEY_DIM, 12); }
    public static int durationSec(Context c) { return p(c).getInt(KEY_DURATION, 7); }
    public static boolean dragMode(Context c) { return p(c).getBoolean(KEY_DRAG, false); }
    public static void setX(Context c, int v) { p(c).edit().putInt(KEY_X, v).apply(); }
    public static void setY(Context c, int v) { p(c).edit().putInt(KEY_Y, v).apply(); }
    public static void setWidthPercent(Context c, int v) { p(c).edit().putInt(KEY_WIDTH, v).apply(); }
    public static void setHeightDp(Context c, int v) { p(c).edit().putInt(KEY_HEIGHT, v).apply(); }
    public static void setRadiusDp(Context c, int v) { p(c).edit().putInt(KEY_RADIUS, v).apply(); }
    public static void setBlurDp(Context c, int v) { p(c).edit().putInt(KEY_BLUR, v).apply(); }
    public static void setDimPercent(Context c, int v) { p(c).edit().putInt(KEY_DIM, v).apply(); }
    public static void setDurationSec(Context c, int v) { p(c).edit().putInt(KEY_DURATION, v).apply(); }
    public static void setDragMode(Context c, boolean v) { p(c).edit().putBoolean(KEY_DRAG, v).apply(); }

    public static void resetPopup(Context c) {
        p(c).edit().remove(KEY_X).remove(KEY_Y).remove(KEY_WIDTH).remove(KEY_HEIGHT)
                .remove(KEY_RADIUS).remove(KEY_BLUR).remove(KEY_DIM).remove(KEY_DURATION)
                .remove(KEY_DRAG).apply();
    }
    private AppPrefs() {}
}
