package com.earpopupx;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public final class EarPopupWindow {
    private final Context context;
    private WindowManager wm;
    private View root;
    private WindowManager.LayoutParams lp;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView title;
    private TextView battery;
    private TextView source;
    private ImageView media;
    private float downX, downY;
    private int startX, startY;

    public EarPopupWindow(Context c) { context = c.getApplicationContext(); }

    public void show(String name, BatteryState state) {
        if (!Settings.canDrawOverlays(context)) return;
        if (root == null) build(name, state); else update(name, state);
        applyLayout();
        root.setVisibility(View.VISIBLE);
        animateIn(root);
        scheduleDismiss();
    }

    public void update(String name, BatteryState state) {
        if (root == null) { show(name, state); return; }
        title.setText(name);
        battery.setText(formatBattery(state));
        source.setText("数据来源 · " + state.source);
    }

    private void build(String name, BatteryState state) {
        wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(232, 248, 249, 250));
        bg.setCornerRadius(dp(AppPrefs.radiusDp(context)));
        card.setBackground(bg);
        card.setElevation(dp(14));
        card.setClipToOutline(true);
        card.setOutlineProvider(new RadiusOutlineProvider(dp(AppPrefs.radiusDp(context))));

        FrameLayout mediaFrame = new FrameLayout(context);
        GradientDrawable mediaBg = new GradientDrawable();
        mediaBg.setColor(Color.argb(90, 255, 255, 255));
        mediaBg.setCornerRadius(dp(Math.max(18, AppPrefs.radiusDp(context) - 10)));
        mediaFrame.setBackground(mediaBg);
        mediaFrame.setClipToOutline(true);
        mediaFrame.setOutlineProvider(new RadiusOutlineProvider(dp(Math.max(18, AppPrefs.radiusDp(context) - 10))));
        media = new ImageView(context);
        media.setScaleType(ImageView.ScaleType.CENTER_CROP);
        loadMedia(media);
        mediaFrame.addView(media, new FrameLayout.LayoutParams(-1, dp(285)));
        card.addView(mediaFrame, new LinearLayout.LayoutParams(-1, dp(285)));

        FrameLayout titleRow = new FrameLayout(context);
        title = text(name, 24, true);
        title.setTextColor(Color.rgb(20, 20, 22));
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, dp(54));
        tp.leftMargin = dp(8); tp.rightMargin = dp(52);
        titleRow.addView(title, tp);

        ImageButton close = new ImageButton(context);
        close.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        close.setColorFilter(Color.rgb(65, 65, 68));
        GradientDrawable closeBg = new GradientDrawable();
        closeBg.setColor(Color.argb(80, 120, 120, 125));
        closeBg.setShape(GradientDrawable.OVAL);
        close.setBackground(closeBg);
        close.setContentDescription("关闭弹窗");
        close.setOnClickListener(v -> dismiss());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        cp.rightMargin = dp(2);
        titleRow.addView(close, cp);
        card.addView(titleRow, new LinearLayout.LayoutParams(-1, dp(56)));

        battery = text(formatBattery(state), 18, true);
        battery.setTextColor(Color.rgb(35, 35, 38));
        battery.setGravity(Gravity.CENTER);
        battery.setPadding(dp(8), dp(2), dp(8), dp(4));
        card.addView(battery, new LinearLayout.LayoutParams(-1, dp(72)));

        source = text("数据来源 · " + state.source, 11, false);
        source.setTextColor(Color.rgb(105, 105, 110));
        source.setGravity(Gravity.CENTER);
        card.addView(source, new LinearLayout.LayoutParams(-1, dp(28)));

        root = card;
        if (AppPrefs.dragMode(context)) attachDrag(root);

        lp = new WindowManager.LayoutParams();
        lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        lp.format = PixelFormat.TRANSLUCENT;
        lp.gravity = Gravity.CENTER;
        lp.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        lp.dimAmount = AppPrefs.dimPercent(context) / 100f;
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                if (wm.isCrossWindowBlurEnabled()) {
                    lp.setBlurBehindRadius(dp(AppPrefs.blurDp(context)));
                    lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                }
            } catch (Throwable ignored) {}
        }
        try { wm.addView(root, lp); } catch (Throwable t) { root = null; }
    }

    private void attachDrag(View v) {
        v.setOnTouchListener((view, event) -> {
            if (!AppPrefs.dragMode(context)) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX(); downY = event.getRawY();
                    startX = lp.x; startY = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = startX + Math.round(event.getRawX() - downX);
                    lp.y = startY + Math.round(event.getRawY() - downY);
                    try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    AppPrefs.setX(context, lp.x); AppPrefs.setY(context, lp.y);
                    return true;
            }
            return true;
        });
    }

    private void applyLayout() {
        if (lp == null || root == null) return;
        lp.width = (int) (getWidth() * (AppPrefs.widthPercent(context) / 100f));
        lp.height = dp(AppPrefs.heightDp(context));
        lp.x = AppPrefs.x(context); lp.y = AppPrefs.y(context);
        lp.dimAmount = AppPrefs.dimPercent(context) / 100f;
        try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) {}
    }

    private void scheduleDismiss() { handler.removeCallbacksAndMessages(null); handler.postDelayed(this::dismiss, Math.max(2, AppPrefs.durationSec(context)) * 1000L); }

    private void animateIn(View v) {
        v.setAlpha(0f); v.setScaleX(.94f); v.setScaleY(.94f);
        AnimatorSet s = new AnimatorSet();
        s.playTogether(ObjectAnimator.ofFloat(v, "alpha", 0f, 1f), ObjectAnimator.ofFloat(v, "scaleX", .94f, 1f), ObjectAnimator.ofFloat(v, "scaleY", .94f, 1f));
        s.setDuration(260); s.start();
    }

    public void dismiss() {
        handler.removeCallbacksAndMessages(null);
        if (wm != null && root != null) { try { wm.removeView(root); } catch (Throwable ignored) {} }
        root = null; lp = null;
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(context); t.setText(s); t.setTextSize(size); t.setTypeface(null, bold ? 1 : 0); return t;
    }

    private String formatBattery(BatteryState s) {
        if (s.left >= 0 || s.right >= 0 || s.caseLevel >= 0) {
            String l = s.left >= 0 ? "左耳 " + s.left + "%" : "左耳 —";
            String r = s.right >= 0 ? "右耳 " + s.right + "%" : "右耳 —";
            String c = s.caseLevel >= 0 ? "盒子 " + s.caseLevel + "%" : "盒子 —";
            return l + "    " + r + "    " + c;
        }
        return s.aggregate >= 0 ? "电量  " + s.aggregate + "%" : "正在读取电量…";
    }

    private void loadMedia(ImageView v) {
        String raw = AppPrefs.media(context);
        if (raw == null) return;
        try {
            Uri u = Uri.parse(raw);
            ImageDecoder.Source src = ImageDecoder.createSource(context.getContentResolver(), u);
            Drawable d = ImageDecoder.decodeDrawable(src);
            v.setImageDrawable(d);
            if (d instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) d).start();
        } catch (Throwable ignored) {}
    }

    private int dp(int n) { return (int) (n * context.getResources().getDisplayMetrics().density + .5f); }
    private int getWidth() { return context.getResources().getDisplayMetrics().widthPixels; }
    private static final class RadiusOutlineProvider extends ViewOutlineProvider {
        private final float r; RadiusOutlineProvider(float radius) { r = radius; }
        @Override public void getOutline(View view, Outline outline) { outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r); }
    }
}
