package com.earpopupx;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public final class MainActivity extends Activity {
    private static final int REQ_BT = 10, REQ_NOTIFY = 11, REQ_MEDIA = 12;
    private TextView status, posLabel;
    private SeekBar xBar, yBar, widthBar, heightBar, radiusBar, blurBar, dimBar, durationBar;
    private Switch autoSwitch, dragSwitch;

    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(R.layout.activity_main); bind(); updateStatus(); }
    private void bind() {
        status = findViewById(R.id.status); posLabel = findViewById(R.id.posLabel);
        findViewById(R.id.overlay).setOnClickListener(v -> openOverlay());
        findViewById(R.id.bluetooth).setOnClickListener(v -> requestBluetooth());
        findViewById(R.id.notifications).setOnClickListener(v -> requestNotifications());
        findViewById(R.id.battery).setOnClickListener(v -> openBatteryOptimization());
        findViewById(R.id.start).setOnClickListener(v -> startMonitor());
        findViewById(R.id.test).setOnClickListener(v -> testPopup());
        findViewById(R.id.pick).setOnClickListener(v -> pickMedia());
        findViewById(R.id.resetMedia).setOnClickListener(v -> { AppPrefs.setMedia(this, null); Toast.makeText(this, "已恢复默认媒体", Toast.LENGTH_SHORT).show(); });
        findViewById(R.id.resetPopup).setOnClickListener(v -> { AppPrefs.resetPopup(this); syncBars(); Toast.makeText(this, "弹窗参数已恢复默认", Toast.LENGTH_SHORT).show(); });
        autoSwitch = findViewById(R.id.autoSwitch); dragSwitch = findViewById(R.id.dragSwitch);
        autoSwitch.setChecked(AppPrefs.enabled(this)); dragSwitch.setChecked(AppPrefs.dragMode(this));
        autoSwitch.setOnCheckedChangeListener((b, checked) -> AppPrefs.setEnabled(this, checked));
        dragSwitch.setOnCheckedChangeListener((b, checked) -> { AppPrefs.setDragMode(this, checked); Toast.makeText(this, checked ? "测试弹窗现在可以直接拖动" : "拖动调试已关闭", Toast.LENGTH_SHORT).show(); });
        xBar=findViewById(R.id.xBar); yBar=findViewById(R.id.yBar); widthBar=findViewById(R.id.widthBar); heightBar=findViewById(R.id.heightBar); radiusBar=findViewById(R.id.radiusBar); blurBar=findViewById(R.id.blurBar); dimBar=findViewById(R.id.dimBar); durationBar=findViewById(R.id.durationBar);
        xBar.setMax(300); yBar.setMax(600); widthBar.setMax(16); heightBar.setMax(420); radiusBar.setMax(60); blurBar.setMax(80); dimBar.setMax(35); durationBar.setMax(18);
        syncBars();
        xBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setX(this, p-150))); yBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setY(this,p-300)));
        widthBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setWidthPercent(this,p+84))); heightBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setHeightDp(this,p+380)));
        radiusBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setRadiusDp(this,p))); blurBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setBlurDp(this,p)));
        dimBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setDimPercent(this,p))); durationBar.setOnSeekBarChangeListener(seek((p,f)->AppPrefs.setDurationSec(this,p+2)));
    }
    private SeekBar.OnSeekBarChangeListener seek(final Setter s) { return new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar b,int p,boolean f){ s.set(p,f); updatePositionLabel(); } public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){} }; }
    private interface Setter { void set(int p, boolean fromUser); }
    private void syncBars(){ xBar.setProgress(AppPrefs.x(this)+150); yBar.setProgress(AppPrefs.y(this)+300); widthBar.setProgress(AppPrefs.widthPercent(this)-84); heightBar.setProgress(AppPrefs.heightDp(this)-380); radiusBar.setProgress(AppPrefs.radiusDp(this)); blurBar.setProgress(AppPrefs.blurDp(this)); dimBar.setProgress(AppPrefs.dimPercent(this)); durationBar.setProgress(AppPrefs.durationSec(this)-2); updatePositionLabel(); }
    private void updatePositionLabel(){ posLabel.setText("位置 X " + AppPrefs.x(this) + " / Y " + AppPrefs.y(this) + " · 宽度 " + AppPrefs.widthPercent(this) + "% · 高度 " + AppPrefs.heightDp(this) + "dp"); }
    private void openOverlay(){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }
    private void requestBluetooth(){ if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT); }
    private void requestNotifications(){ if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFY); }
    private void openBatteryOptimization(){ try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:"+getPackageName()))); } catch(Throwable t) { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } }
    private void pickMedia(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,REQ_MEDIA); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==REQ_MEDIA&&c==RESULT_OK&&d!=null&&d.getData()!=null){ try{getContentResolver().takePersistableUriPermission(d.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Throwable ignored){} AppPrefs.setMedia(this,d.getData()); Toast.makeText(this,"图片 / GIF 已保存",Toast.LENGTH_SHORT).show(); } }
    private void startMonitor(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){ requestBluetooth(); return; }
        if(!Settings.canDrawOverlays(this)){ openOverlay(); return; }
        Intent i=new Intent(this,BluetoothMonitorService.class);
        try { if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); Toast.makeText(this,"监听已启动；之后连接耳机会自动弹出",Toast.LENGTH_SHORT).show(); }
        catch(Throwable t){ Toast.makeText(this,"启动失败：请先完成悬浮窗/蓝牙权限",Toast.LENGTH_LONG).show(); }
    }
    private void testPopup(){ if(!Settings.canDrawOverlays(this)){openOverlay();return;} new EarPopupWindow(this).show("测试耳机 · EarPopup X", BatteryState.unknown("测试模式")); }
    private void updateStatus(){ StringBuilder s=new StringBuilder(); s.append("状态检查\n"); s.append(Settings.canDrawOverlays(this)?"● 悬浮窗已开启\n":"○ 悬浮窗未开启\n"); if(Build.VERSION.SDK_INT>=31)s.append(checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED?"● 蓝牙权限已开启\n":"○ 蓝牙权限未开启\n"); if(Build.VERSION.SDK_INT>=33)s.append(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED?"● 通知权限已开启\n":"○ 通知权限未开启\n"); status.setText(s.toString()); }
    @Override protected void onResume(){ super.onResume(); updateStatus(); }
}
