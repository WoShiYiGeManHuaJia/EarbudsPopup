package com.earpopupx;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

public final class BluetoothMonitorService extends Service {
    private static final String CHANNEL = "earpopupx_monitor";
    private BluetoothBatteryReader reader;
    private EarPopupWindow popup;
    private BroadcastReceiver receiver;
    private String currentAddress;

    @Override public void onCreate() {
        super.onCreate(); createChannel(); reader = new BluetoothBatteryReader(this); popup = new EarPopupWindow(this); register();
    }
    @Override public int onStartCommand(Intent i, int flags, int id) { startAsForeground(); return START_STICKY; }

    private void startAsForeground() {
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("EarPopup X")
                .setContentText("蓝牙耳机监听已运行")
                .setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(7, n);
        } catch (Throwable t) { try { startForeground(7, n); } catch (Throwable ignored) {} }
    }

    private void register() {
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                BluetoothDevice d = getDevice(i);
                if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(a) && d != null) {
                    handleConnected(d);
                } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(a) && d != null) {
                    if (same(d)) { currentAddress = null; popup.dismiss(); }
                } else if ("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED".equals(a) && d != null) {
                    int v = i.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1);
                    if (v >= 0 && v <= 100 && same(d)) popup.update(safeName(d), new BatteryState(v, -1, -1, -1, false, false, false, "系统蓝牙广播"));
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED); f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        f.addAction("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver, f);
    }

    private void handleConnected(BluetoothDevice d) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
        try { currentAddress = d.getAddress(); } catch (Throwable t) { return; }
        if (!AppPrefs.enabled(this)) return;

        // Always show immediately on connection. Battery may arrive later from the Bluetooth stack.
        popup.show(safeName(d), BatteryState.unknown("正在等待系统蓝牙电量"));
        reader.read(d, s -> { if (same(d) && AppPrefs.enabled(this)) popup.update(safeName(d), s); });
    }

    private boolean same(BluetoothDevice d) { try { return currentAddress != null && currentAddress.equals(d.getAddress()); } catch (Throwable t) { return false; } }
    private BluetoothDevice getDevice(Intent i) { try { if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class); return (BluetoothDevice) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); } catch (Throwable t) { return null; } }
    private String safeName(BluetoothDevice d) { try { String n = d.getName(); return n == null || n.trim().isEmpty() ? "蓝牙耳机" : n; } catch (Throwable t) { return "蓝牙耳机"; } }
    private void createChannel() { if (Build.VERSION.SDK_INT >= 26) { NotificationManager nm = getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL, "耳机连接监控", NotificationManager.IMPORTANCE_LOW)); } }
    @Override public void onDestroy() { try { unregisterReceiver(receiver); } catch (Throwable ignored) {} if (popup != null) popup.dismiss(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
