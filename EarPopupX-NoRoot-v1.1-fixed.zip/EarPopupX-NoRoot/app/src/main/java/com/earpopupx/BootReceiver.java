package com.earpopupx;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(a)) {
            start(c);
        }
        // Do not rely on starting a foreground service directly from ACL broadcasts on newer Android.
        // The service is started once from the visible app; it then receives ACL events continuously.
    }
    private void start(Context c) {
        try {
            Intent s = new Intent(c, BluetoothMonitorService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
        } catch (Throwable ignored) {}
    }
}
