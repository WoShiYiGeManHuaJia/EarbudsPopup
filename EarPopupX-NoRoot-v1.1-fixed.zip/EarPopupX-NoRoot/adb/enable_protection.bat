@echo off
setlocal
set PKG=com.earpopupx

echo [1/6] Granting Bluetooth runtime permissions...
adb shell pm grant %PKG% android.permission.BLUETOOTH_CONNECT 2>nul
adb shell pm grant %PKG% android.permission.BLUETOOTH_SCAN 2>nul

echo [2/6] Granting notification permission (Android 13+)...
adb shell pm grant %PKG% android.permission.POST_NOTIFICATIONS 2>nul

echo [3/6] Enabling overlay AppOp...
adb shell appops set %PKG% SYSTEM_ALERT_WINDOW allow

echo [4/6] Adding Doze whitelist...
adb shell cmd deviceidle whitelist +%PKG%
echo [5/6] Relaxing background AppOps...
adb shell cmd appops set %PKG% RUN_IN_BACKGROUND allow
adb shell cmd appops set %PKG% RUN_ANY_IN_BACKGROUND allow

echo [6/6] Restarting app process...
adb shell am force-stop %PKG%
adb shell monkey -p %PKG% 1 >nul 2>&1

echo.
echo Done. On HyperOS, also enable Auto-start and Battery -> No restrictions if those options are shown.
echo NOTE: ADB cannot grant Xiaomi SystemUI signature privileges to a normal APK.
pause
endlocal
