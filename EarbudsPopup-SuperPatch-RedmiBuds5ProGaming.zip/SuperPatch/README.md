# EarbudsPopup Super Patch — Redmi Buds 5 Pro Gaming / HyperOS

目标设备：**Redmi Buds 5 Pro Gaming**  
测试地址：`48:73:CB:63:8E:3A`

## 这次补丁不是继续“猜电量”

你提供的日志已经把问题定位得很明确：

- `0x180F / 0x2A19 = 100` 只有一个实例：这是聚合/主电量，不能拿来同时当左耳和右耳。
- `METADATA_UNTETHERED_LEFT/RIGHT/CASE = null`：普通第三方 App 没拿到 Android SystemApi 元数据。
- `5052494D-2DAB-0341-6972-6F6861424C45`：这是 Airoha RACE 服务；它不是“随便读一个 1~100 字节就是电量”的接口。
- 你日志里的 `43484152...3041 = 0x20` 被之前版本误判为候选电量，这个补丁彻底取消这种猜测。
- Xiaomi/Redmi TWS 有一条更合适的 **经典蓝牙 RFCOMM / MMA** 控制通道，公开逆向资料记录了 `GET_DEVICE_INFO (0x02)` 的电量查询，返回数据明确包含 `LL RR CC` 三路电量。

## 新电量优先级

```text
Redmi/Xiaomi TWS
      ↓
Xiaomi MMA / RFCOMM
      ↓
GET_DEVICE_INFO 0x02
      ↓
LL / RR / CASE
      ↓
真实语义电量

失败
  ↓
系统隐藏电量 / Shizuku dumpsys
  ↓
标准 GATT 0x180F/0x2A19
  ↓
仅作为 aggregate，不再复制成 L/R
```

## 为什么不再猜 Case

Airoha RACE 的私有特征可能承载控制状态、协议字段和其他数据。任何“看到 1~100 就当 Case”的算法都可能把 `0x20`、`0x40` 等状态值误当电量。

本补丁只接受：

1. Xiaomi MMA 明确的 `LL/RR/CC`；
2. Android 明确的 left/right/case metadata；
3. 标准 GATT 多 Battery Service 实例且有明确语义；

否则显示 `--%`，不伪造数字。

## HyperOS Super Island 修复

- 只在 `notification_focus_protocol >= 3` 时走 HyperOS 3 Super Island。
- 不再因为 `canShowFocus()` 查询暂时返回 false 就直接放弃发送。
- 按小米官方客户端结构把 `miui.focus.param` 和 `miui.focus.pics` 放进通知 extras。
- 加入 `islandFirstFloat / enableFloat / updatable / filterWhenNoPermission / timeout`。
- 通知通道提升为 HIGH。
- GIF 不再阻止 Super Island 创建；如果 HyperOS 模板不支持 GIF，岛里使用文字/应用图标，Overlay 仍保留 GIF。

## GIF 性能修复

之前的实时动态模糊会跟随 GIF 每一帧重绘，容易导致掉帧。

现在：

- 不再强制 `stop() → startFromFirstFrame() → start()` 重启 GIF。
- Glide 自己负责 GIF 播放。
- GIF 模式关闭逐帧 LiveBlur。
- 详情区域使用廉价的玻璃/渐变暗层，不再对整张 GIF 做逐帧 StackBlur。
- 静态图片仍可以使用动态模糊。

## 注意

这个补丁仍然需要在你的 Android/Gradle 环境编译。当前生成环境无法联网下载 Gradle 8.2，因此这里不能伪装成“已经编译成功的 APK”。

安装后重点测试：

1. 连接 Redmi Buds 5 Pro Gaming；
2. 看日志是否出现：`MMA: RFCOMM connected...`；
3. 看是否出现：`MMA BATTERY: L=xx R=xx Case=xx`；
4. 如果 MMA 返回超时，日志会明确显示 RFCOMM FD2D / channel 6 / SPP 哪一步失败；
5. 若超级岛仍不上岛，查看应用是否获得 HyperOS 的焦点/超级岛通知资格。
