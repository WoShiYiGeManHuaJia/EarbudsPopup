package com.woshiyigemanhuajia.btpopup.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 详情区「实时模糊背景层」。
 *
 * 移植自参考实现 ui_ref/2_弹窗渲染逻辑/LiveBlurView.java，保留其全部关键处理：
 *  1. 绑定源 ImageView 的 Drawable 做**一次性快照模糊**（不再转发逐帧回调）：
 *     源 / 尺寸 / 半径 / 拉伸比不变时直接复用上一次的模糊位图，
 *     GIF 播放期间本层完全不参与逐帧重算与重绘，因此不会拖慢 GIF、也不会让文字区糊成一片。
 *  2. 手动模糊流水线：降采样 → StackBlur → 放大回原尺寸，
 *     缓冲区全部缓存复用，逐帧执行不产生 GC 抖动。
 *  3. 顶部渐隐带（fadeGradient + DST_OUT）：模糊层上沿柔和融进上方清晰画面，
 *     **不做"一刀切"硬边**；渐隐带高度占比由 fadeRatio 控制。
 *  4. 底部两角圆角跟随卡片圆角（shaderPaint 填充圆角路径），不会盖掉卡片圆角。
 *  5. 强制软件渲染并禁用 outline 裁剪，避免 alpha 动画期间圆角/合成时有时无。
 */
class LiveBlurView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        private const val TAG = "LiveBlur"
    }

    private var src: ImageView? = null

    /**
     * 模糊源位图：由弹窗层独立交付（见 PopupOverlayManager.prefetchBlurSource），
     * 与 popupImage 的 Drawable **完全不共享**，因此不会干扰图片 / GIF 自身的绘制。
     * null 表示暂无源，本层保持透明不绘制。
     */
    private var sourceBitmap: Bitmap? = null

    /** 模糊半径（px，按 View 空间计） */
    private var blurRadiusPx = 26f

    /** 压暗色，保证白色文字在任意图片上都可读 */
    private var dimColor = 0x4D000000

    /** 顶部渐隐带高度占本 View 高度的比例；0 = 不做渐隐（硬边） */
    private var fadeRatio = 0.25f

    /** 底部两角圆角半径（px），与卡片圆角一致 */
    private var bottomRadiusPx = 0f

    private val shaderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fadePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val upscalePaint = Paint(Paint.FILTER_BITMAP_FLAG)

    private var fadeGradient: LinearGradient? = null
    private var cornerPath: Path? = null

    /** 上一次模糊结果的指纹：源 / 尺寸 / 半径 / 拉伸比 / 压暗色只要没变就直接复用位图，不再重算 */
    private var blurredKey: String? = null
    private var blurredCache: Bitmap? = null

    /** 动画源（GIF）的一次性定格快照：本层只碰它一次，之后不再打扰动画对象 */
    private var animSnapshot: Bitmap? = null
    private var animSnapshotKey: String? = null

    private val snapshotPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    // ---- StackBlur 缓冲区：尺寸变化时才重建 ----
    private var bufPix: IntArray? = null
    private var bufR: IntArray? = null
    private var bufG: IntArray? = null
    private var bufB: IntArray? = null
    private var bufA: IntArray? = null
    private var bufVmin: IntArray? = null
    private var bufDv: IntArray? = null
    private var bufStack: Array<IntArray>? = null

    private var smallBuf: Bitmap? = null
    private var smallCanvas: Canvas? = null
    private var outBuf: Bitmap? = null
    private var outCanvas: Canvas? = null

    init {
        dimPaint.color = dimColor
        // 禁用 RenderEffect / outline 裁剪：二者与 alpha 动画、圆角合成互相干扰，
        // 圆角改由 onDraw 内的路径裁剪实现，稳定可控。
        setClipToOutline(false)
        // 不再强制软件层：软件层会让本层与 GIF 每帧的脏区一起在 CPU 上重新光栅化、
        // 再整体上传纹理，是"GIF 播放很卡"的又一处来源（尤其在横屏，模糊层与图片区重叠时）。
        // 模糊结果已经一次性算好并缓存，交给 GPU 直接合成即可；
        // 圆角路径 / DST_OUT 渐隐在硬件加速下同样支持。
        setLayerType(View.LAYER_TYPE_NONE, null)
    }

    // ------------------------------------------------------------------ 对外 API

    /** 绑定源 ImageView（弹窗里那张图 / GIF） */
    fun setSource(source: ImageView?) {
        if (src === source) {
            // 同一个源：不主动丢缓存（源图换了内容时 blurKey 里的指纹会变，自动失效）
            invalidate()
            return
        }
        src = source
        animSnapshot = null
        animSnapshotKey = null
        invalidateBlur()
        invalidate()
    }

    /**
     * 直接交付一份**独立**的源位图作为模糊源（推荐用法）。
     *
     * 与 [setSource] 的区别：本方法只持有位图，绝不触碰 ImageView 的 Drawable，
     * 因此不会与图片 / GIF 自身绘制互相干扰；GIF 场景传入的是首帧快照，
     * 播放期间本层不参与重算，既不卡动画也不闪。
     *
     * @param bmp 源位图；传 null 表示清空（本层保持透明不绘制）
     */
    fun setSourceBitmap(bmp: Bitmap?) {
        if (sourceBitmap === bmp) return
        sourceBitmap = bmp
        invalidateBlur()
        invalidate()
    }

    /** 当前是否已有可用模糊源（无源时本层不绘制任何内容） */
    fun hasSource(): Boolean = sourceBitmap?.isRecycled == false

    fun setBlurRadius(px: Float) {
        blurRadiusPx = max(0f, px)
        invalidate()
    }

    /** 叠加的半透明色（argb），保证文字可读 */
    fun setDim(argb: Int) {
        dimColor = argb
        dimPaint.color = argb
        invalidate()
    }

    /** 设置底部两角圆角半径（px），与卡片圆角保持一致 */
    fun setBottomCornerRadius(px: Float) {
        bottomRadiusPx = max(0f, px)
        cornerPath = null
        invalidate()
    }

    /**
     * 横向放大倍数：本层比源 ImageView 更宽时（例如竖屏卡片带内边距），按比例把源内容横向拉满，
     * 避免边缘露出未模糊的空档。1 = 不放大。只影响水平方向，垂直方向仍只取底部一段。
     */
    private var sourceScaleX = 1f

    fun setSourceScaleX(scale: Float) {
        val s = max(1f, scale)
        if (abs(s - sourceScaleX) < 0.001f) return
        sourceScaleX = s
        invalidate()
    }

    /** 设置顶部渐隐带高度占比（0 = 硬边，1 = 整层渐隐） */
    fun setFadeRatio(r: Float) {
        fadeRatio = r.coerceIn(0f, 1f)
        fadeGradient = null
        invalidate()
    }

    // ------------------------------------------------------------------ 模糊结果缓存

    /**
     * 源内容 / 尺寸 / 半径 / 拉伸比 / 压暗色任一变化才重算。
     * 参数不变时直接复用上一次的模糊位图 —— 关键点：**GIF 播放过程中本层完全不参与**，
     * 既不逐帧重算 StackBlur，也不抢逐帧重绘，因此 GIF 动画不会被拖卡；
     * 模糊背景取的是源图定格的那一帧，文字区依旧有柔和的毛玻璃底，且不影响文字清晰度。
     */
    private fun blurKey(dr: Drawable, vw: Int, vh: Int): String {
        val s = src
        val sw = if (s != null && s.width > 0) s.width else vw
        val sh = if (s != null && s.height > 0) s.height else vh
        return System.identityHashCode(dr).toString() + "|" + sw + "x" + sh + "|" + vw + "x" + vh +
            "|" + blurRadiusPx + "|" + sourceScaleX + "|" + dimColor
    }

    private fun invalidateBlur() {
        blurredKey = null
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // 尺寸变了必须丢弃旧圆角路径与旧模糊结果，否则会一直用第一次的尺寸绘制
        cornerPath = null
        fadeGradient = null
        invalidateBlur()
    }

    // ------------------------------------------------------------------ 绘制

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        // 模糊源 = 外部独立交付的位图（setSourceBitmap）。
        // 【黑色一刀切修复】绝不再从 popupImage 的 Drawable 取源：
        //   1) 读它的 Drawable 需要临时改写 bounds / matrix，会与 ImageView 自身绘制互相干扰
        //      → 横屏出现"设置了图片 / GIF 却看不见"；
        //   2) ImageView 还没拿到 Drawable 时旧逻辑整层只涂压暗色 → 就是用户看到的"黑色一刀切"。
        // 现在没有源位图就什么都不画（保持完全透明），绝不画整块黑色。
        val srcBmp = sourceBitmap
        if (srcBmp == null || srcBmp.isRecycled) return
        val key = "bmp|" + System.identityHashCode(srcBmp) + "|" + w + "x" + h +
            "|" + blurRadiusPx + "|" + dimColor
        var bmp = blurredCache
        if (bmp == null || key != blurredKey) {
            try {
                bmp = renderBlurredFromBitmap(srcBmp, w, h)
                blurredCache = bmp
                blurredKey = key
            } catch (t: Throwable) {
                Log.e(TAG, "模糊绘制失败，本轮跳过绘制", t)
                return
            }
        }
        drawBlur(canvas, bmp, w, h)
    }

    private fun drawBlur(canvas: Canvas, bmp: Bitmap, w: Int, h: Int) {
        ensureCornerPath(w, h)
        shaderPaint.shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)

        val layer = canvas.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
        try {
            val path = cornerPath
            if (path != null) {
                canvas.drawPath(path, shaderPaint)
                canvas.drawPath(path, dimPaint)
            } else {
                canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), shaderPaint)
                canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), dimPaint)
            }
            // 顶部渐隐：DST_OUT 从本层里"擦掉"顶部那段，露出上方清晰画面
            ensureGradient(w, h)
            val fg = fadeGradient
            if (fg != null && fadeRatio > 0f) {
                canvas.drawRect(0f, 0f, w.toFloat(), h * fadeRatio, fadePaint)
            }
        } finally {
            canvas.restoreToCount(layer)
        }
    }

    /** 顶部渐隐：y=0 全擦除（透明，露出清晰画面）→ y=fh 不擦除（保留模糊层） */
    private fun ensureGradient(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val fh = h * fadeRatio
        if (fh <= 0f) {
            fadeGradient = null
            return
        }
        if (fadeGradient == null) {
            fadeGradient = LinearGradient(
                0f, 0f, 0f, fh,
                0xFF000000.toInt(), 0x00000000,
                Shader.TileMode.CLAMP
            )
            fadePaint.shader = fadeGradient
            fadePaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        }
    }

    /** 底部两角圆角、顶部两角直角的路径 */
    private fun ensureCornerPath(w: Int, h: Int) {
        if (bottomRadiusPx <= 0f || w <= 0 || h <= 0) {
            cornerPath = null
            return
        }
        if (cornerPath != null) return
        val r = min(bottomRadiusPx, min(w, h) / 2f)
        val p = Path()
        p.moveTo(0f, 0f)
        p.lineTo(w.toFloat(), 0f)
        p.lineTo(w.toFloat(), h - r)
        p.arcTo(RectF(w - 2 * r, h - 2 * r, w.toFloat(), h.toFloat()), 0f, 90f)
        p.lineTo(r, h.toFloat())
        p.arcTo(RectF(0f, h - 2 * r, 2 * r, h.toFloat()), 90f, 90f)
        p.close()
        cornerPath = p
    }

    // ------------------------------------------------------------------ 模糊流水线

    /**
     * 降采样 → StackBlur → 放大回 View 尺寸（源为**独立位图**）。
     *
     * 取源位图「底部与本层等高」的一段：本层贴在卡片底部、宽度与上方图片一致，
     * 按宽度对齐后取底部一段，模糊内容就能和上方清晰画面自然接续。
     */
    private fun renderBlurredFromBitmap(src: Bitmap, vw: Int, vh: Int): Bitmap {
        val factor = 4
        val bw = max(1, vw / factor)
        val bh = max(1, vh / factor)

        var sb = smallBuf
        if (sb == null || sb.width != bw || sb.height != bh) {
            sb = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            smallBuf = sb
            smallCanvas = Canvas(sb)
        }
        val sc = smallCanvas!!
        sb.eraseColor(Color.TRANSPARENT)
        sc.save()
        sc.scale(1f / factor, 1f / factor)
        val iw = src.width
        val ih = src.height
        if (iw <= 0 || ih <= 0) {
            sc.restore()
            throw IllegalStateException("源位图尺寸非法 ${iw}x$ih")
        }
        val scale = vw.toFloat() / iw
        val cropH = min(ih, max(1, (vh / scale).roundToInt()))
        val srcRect = android.graphics.Rect(0, ih - cropH, iw, ih)
        val dstRect = android.graphics.Rect(0, 0, vw, vh)
        sc.drawBitmap(src, srcRect, dstRect, snapshotPaint)
        sc.restore()

        // 半径相对小图尺寸取；横屏详情区很扁（bh 只有二三十像素），
        // 上限放宽到较短边的 1/2、下限提到 5，保证扁层也有肉眼可见的柔和模糊，
        // 不会因为半径被压到 2~3 而"看起来只有一条压暗色带"。
        val maxR = max(6, min(bw, bh) / 2)
        val radius = min(maxR, max(5, (blurRadiusPx / 8f).roundToInt()))
        try {
            stackBlur(sb, radius)
        } catch (t: Throwable) {
            Log.e(TAG, "stackBlur 失败 r=$radius small=${bw}x$bh", t)
        }

        var ob = outBuf
        if (ob == null || ob.width != vw || ob.height != vh) {
            ob = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888)
            outBuf = ob
            outCanvas = Canvas(ob)
        }
        val oc = outCanvas!!
        ob.eraseColor(Color.TRANSPARENT)
        oc.save()
        oc.scale(factor.toFloat(), factor.toFloat())
        oc.drawBitmap(sb, 0f, 0f, upscalePaint)
        oc.restore()
        return ob
    }

    /** 降采样 → StackBlur → 放大回 View 尺寸 */
    private fun renderBlurredBitmap(dr: Drawable, sw: Int, sh: Int, vw: Int, vh: Int): Bitmap {
        // 采样倍率越大 → 参与模糊的像素越少 → 一次性重算也足够快；模糊本身是低通，看不出差别
        val factor = 4
        val bw = max(1, vw / factor)
        val bh = max(1, vh / factor)

        var sb = smallBuf
        if (sb == null || sb.width != bw || sb.height != bh) {
            sb = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            smallBuf = sb
            smallCanvas = Canvas(sb)
        }
        val sc = smallCanvas!!
        sb.eraseColor(Color.TRANSPARENT)
        sc.save()
        sc.scale(1f / factor, 1f / factor)
        drawSource(sc, dr, sw, sh, vh)
        sc.restore()

        // 半径相对小图尺寸取：太小成马赛克，太大糊成一片纯色。
        // 【横屏一刀切修复】横屏详情区很扁（模糊层只有 80~100dp），若上限按"较短边 / 8"取，
        // bh 只有二三十像素，半径会被压到 2~3，模糊几乎消失、只剩一条压暗色带 —— 视觉上
        // 就是"模糊变成一刀切、特别难看"。这里放宽：以较短边的 1/2 为上限，
        // 并给半径一个不小于 5 的下限，保证扁层同样有肉眼可见的柔和模糊。
        val maxR = max(6, min(bw, bh) / 2)
        val radius = min(maxR, max(5, (blurRadiusPx / 8f).roundToInt()))
        try {
            stackBlur(sb, radius)
        } catch (t: Throwable) {
            Log.e(TAG, "stackBlur 失败 r=$radius small=${bw}x$bh", t)
            try {
                stackBlur(sb, 6)
            } catch (t2: Throwable) {
                Log.e(TAG, "stackBlur 兜底也失败", t2)
            }
        }

        var ob = outBuf
        if (ob == null || ob.width != vw || ob.height != vh) {
            ob = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888)
            outBuf = ob
            outCanvas = Canvas(ob)
        }
        val oc = outCanvas!!
        ob.eraseColor(Color.TRANSPARENT)
        oc.save()
        oc.scale(factor.toFloat(), factor.toFloat())
        oc.drawBitmap(sb, 0f, 0f, upscalePaint)
        oc.restore()
        return ob
    }

    /**
     * 把源内容画出来，只取它【底部 vh 高度】那一段（模糊层贴在卡片底部）。
     * 用 src.getImageMatrix() 保证与 ImageView 屏幕上的显示完全一致。
     */
    private fun drawSource(canvas: Canvas, dr: Drawable, sw: Int, sh: Int, vh: Int) {
        // 动画源（GIF / 逐帧）先取一次定格快照，之后本层只画这张位图：
        // 反复改动画 drawable 的 bounds / 拿它当绘制源会打断播放节奏，
        // 正是"一开模糊 GIF 就卡、还容易重播"的诱因之一。
        val snap = if (dr is Animatable) animSnapshot(dr, sw, sh) else null

        canvas.save()
        // 源 Drawable 是 ImageView 与本层共用的同一个对象，
        // 直接改它的 bounds 会污染 ImageView 下一帧的绘制
        //（FIT_XY / CENTER 等不走 mDrawMatrix 的缩放模式会因此画错位）。
        // 这里先备份，用完在 finally 里原样还原，只借用一帧。
        val oldBounds = android.graphics.Rect(dr.bounds)
        try {
            if (sourceScaleX != 1f) {
                // 以源视图左边为基准横向拉满（模糊层比源更宽时），垂直方向不受影响
                canvas.scale(sourceScaleX, 1f)
            }
            canvas.translate(0f, -(sh - vh).toFloat())
            val m = src?.imageMatrix
            if (m != null && !m.isIdentity) {
                canvas.concat(m)
            } else {
                val iw0 = if (snap != null) snap.width else dr.intrinsicWidth
                val ih0 = if (snap != null) snap.height else dr.intrinsicHeight
                if (iw0 > 0 && ih0 > 0) {
                    val scale = max(sw.toFloat() / iw0, sh.toFloat() / ih0)
                    canvas.scale(scale, scale)
                    canvas.translate((sw - iw0 * scale) / 2f / scale, (sh - ih0 * scale) / 2f / scale)
                }
            }
            if (snap != null) {
                canvas.drawBitmap(snap, 0f, 0f, snapshotPaint)
            } else {
                var iw = dr.intrinsicWidth
                var ih = dr.intrinsicHeight
                if (iw <= 0 || ih <= 0) {
                    iw = sw
                    ih = sh
                }
                dr.setBounds(0, 0, iw, ih)
                dr.draw(canvas)
            }
        } finally {
            // 动画源全程不碰 drawable 的 bounds；只有静态源才做过临时改写，这里还原
            if (snap == null) dr.setBounds(oldBounds)
            canvas.restore()
        }
    }

    /**
     * 动画源的一次性定格快照。
     * 宽度按上限缩小（模糊本身就是低通滤波，缩小后看不出差别），
     * 快照只在源 / 尺寸变化时重取一次，播放期间本层完全不参与。
     */
    private fun animSnapshot(dr: Drawable, sw: Int, sh: Int): Bitmap? {
        val key = System.identityHashCode(dr).toString() + "|" + sw + "x" + sh
        animSnapshot?.let { if (animSnapshotKey == key) return it }
        return try {
            val w = max(1, min(sw, 512))
            val h = max(1, (w.toFloat() * sh / max(1, sw)).roundToInt())
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val old = android.graphics.Rect(dr.bounds)
            dr.setBounds(0, 0, w, h)
            dr.draw(c)
            dr.setBounds(old)
            animSnapshot = bmp
            animSnapshotKey = key
            bmp
        } catch (t: Throwable) {
            Log.w(TAG, "动画源快照失败，退化为直接绘制源", t)
            null
        }
    }

    // ---- StackBlur 缓冲区尺寸记录：必须按 w 和 h 分别判断，不能只比 w*h ----
    // 反例：100×400 与 800×50 像素总数相同，旧逻辑只比总数会复用旧缓冲区，
    // 而 bufVmin 只有 max(100,400)+1=401 长，水平扫描到 x≥401 时 vmin[x] 直接越界崩溃
    // —— 调宽度 / 大小滑块时模糊层尺寸连续变化，恰好命中就是"概率性闪退"。
    private var bufW = 0
    private var bufH = 0

    private fun ensureBuffers(w: Int, h: Int) {
        if (bufW == w && bufH == h && bufPix != null) return
        val wh = w * h
        bufPix = IntArray(wh)
        bufR = IntArray(wh)
        bufG = IntArray(wh)
        bufB = IntArray(wh)
        bufA = IntArray(wh)
        bufVmin = IntArray(max(w, h) + 1)
        bufDv = null
        bufStack = null
        bufW = w
        bufH = h
    }

    /** Mario Klingemann StackBlur：真高斯近似，缓冲区全部复用 */
    private fun stackBlur(bmp: Bitmap, radiusIn: Int) {
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0 || radiusIn < 1) return
        val radius = min(radiusIn, max(1, min(w, h) / 2))

        ensureBuffers(w, h)
        val pix = bufPix!!
        val r = bufR!!
        val g = bufG!!
        val b = bufB!!
        val a = bufA!!
        val vmin = bufVmin!!
        bmp.getPixels(pix, 0, w, 0, 0, w, h)

        val wm = w - 1
        val hm = h - 1
        val div = radius * 2 + 1
        val divsum = ((div + 1) shr 1) * ((div + 1) shr 1)
        val r1 = radius + 1

        var dv = bufDv
        if (dv == null || dv.size < 256 * divsum) {
            dv = IntArray(256 * divsum)
            bufDv = dv
        }
        val dvv = dv
        for (i in 0 until 256 * divsum) dvv[i] = i / divsum

        var stack = bufStack
        if (stack == null || stack.size < div) {
            stack = Array(max(div, 16)) { IntArray(4) }
            bufStack = stack
        }
        val st = stack

        // ---- 水平方向 ----
        var yw = 0
        var yi = 0
        for (y in 0 until h) {
            var rinsum = 0
            var ginsum = 0
            var binsum = 0
            var ainsum = 0
            var routsum = 0
            var goutsum = 0
            var boutsum = 0
            var aoutsum = 0
            var rsum = 0
            var gsum = 0
            var bsum = 0
            var asum = 0

            for (i in -radius..radius) {
                val p = pix[yi + min(wm, max(i, 0))]
                val sir = st[i + radius]
                sir[0] = (p shr 16) and 0xff
                sir[1] = (p shr 8) and 0xff
                sir[2] = p and 0xff
                sir[3] = (p ushr 24) and 0xff
                val rbs = r1 - abs(i)
                rsum += sir[0] * rbs
                gsum += sir[1] * rbs
                bsum += sir[2] * rbs
                asum += sir[3] * rbs
                if (i > 0) {
                    rinsum += sir[0]
                    ginsum += sir[1]
                    binsum += sir[2]
                    ainsum += sir[3]
                } else {
                    routsum += sir[0]
                    goutsum += sir[1]
                    boutsum += sir[2]
                    aoutsum += sir[3]
                }
            }

            var stackpointer = radius
            for (x in 0 until w) {
                r[yi] = dvv[rsum]
                g[yi] = dvv[gsum]
                b[yi] = dvv[bsum]
                a[yi] = dvv[asum]

                rsum -= routsum
                gsum -= goutsum
                bsum -= boutsum
                asum -= aoutsum

                val stackstart = stackpointer - radius + div
                var sir = st[stackstart % div]

                routsum -= sir[0]
                goutsum -= sir[1]
                boutsum -= sir[2]
                aoutsum -= sir[3]

                if (y == 0) vmin[x] = min(x + r1, wm)

                val p = pix[yw + vmin[x]]
                sir[0] = (p shr 16) and 0xff
                sir[1] = (p shr 8) and 0xff
                sir[2] = p and 0xff
                sir[3] = (p ushr 24) and 0xff

                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]
                ainsum += sir[3]

                rsum += rinsum
                gsum += ginsum
                bsum += binsum
                asum += ainsum

                stackpointer = (stackpointer + 1) % div
                sir = st[stackpointer % div]

                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]
                aoutsum += sir[3]

                rinsum -= sir[0]
                ginsum -= sir[1]
                binsum -= sir[2]
                ainsum -= sir[3]

                yi++
            }
            yw += w
        }

        // ---- 垂直方向 ----
        for (x in 0 until w) {
            var rinsum = 0
            var ginsum = 0
            var binsum = 0
            var ainsum = 0
            var routsum = 0
            var goutsum = 0
            var boutsum = 0
            var aoutsum = 0
            var rsum = 0
            var gsum = 0
            var bsum = 0
            var asum = 0
            var yp = -radius * w

            for (i in -radius..radius) {
                val index = max(0, yp) + x
                val sir = st[i + radius]
                sir[0] = r[index]
                sir[1] = g[index]
                sir[2] = b[index]
                sir[3] = a[index]
                val rbs = r1 - abs(i)
                rsum += r[index] * rbs
                gsum += g[index] * rbs
                bsum += b[index] * rbs
                asum += a[index] * rbs
                if (i > 0) {
                    rinsum += sir[0]
                    ginsum += sir[1]
                    binsum += sir[2]
                    ainsum += sir[3]
                } else {
                    routsum += sir[0]
                    goutsum += sir[1]
                    boutsum += sir[2]
                    aoutsum += sir[3]
                }
                if (i < hm) yp += w
            }

            yi = x
            var stackpointer = radius
            for (y in 0 until h) {
                pix[yi] = (dvv[asum] shl 24) or (dvv[rsum] shl 16) or (dvv[gsum] shl 8) or dvv[bsum]

                rsum -= routsum
                gsum -= goutsum
                bsum -= boutsum
                asum -= aoutsum

                val stackstart = stackpointer - radius + div
                var sir = st[stackstart % div]

                routsum -= sir[0]
                goutsum -= sir[1]
                boutsum -= sir[2]
                aoutsum -= sir[3]

                if (x == 0) vmin[y] = min(y + r1, hm) * w

                val p = x + vmin[y]
                sir[0] = r[p]
                sir[1] = g[p]
                sir[2] = b[p]
                sir[3] = a[p]

                rinsum += sir[0]
                ginsum += sir[1]
                binsum += sir[2]
                ainsum += sir[3]

                rsum += rinsum
                gsum += ginsum
                bsum += binsum
                asum += ainsum

                stackpointer = (stackpointer + 1) % div
                sir = st[stackpointer % div]

                routsum += sir[0]
                goutsum += sir[1]
                boutsum += sir[2]
                aoutsum += sir[3]

                rinsum -= sir[0]
                ginsum -= sir[1]
                binsum -= sir[2]
                ainsum -= sir[3]

                yi += w
            }
        }

        bmp.setPixels(pix, 0, w, 0, 0, w, h)
    }
}
