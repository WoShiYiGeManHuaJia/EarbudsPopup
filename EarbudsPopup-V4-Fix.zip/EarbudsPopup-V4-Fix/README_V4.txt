Earbuds Popup V4 修正版

针对：Redmi Buds 5 Pro Gaming / HyperOS 3

本包修复：
- 不再把单一 0x180F / getBatteryLevel() 复制为左右耳电量
- 不再从任意 NOTIFY 猜充电盒
- 恢复充电盒 UI 槽位，未知显示 --%
- 修复 dumpsys BATTERY=100 误判
- 降低 GIF 动态模糊刷新负载，修正渐隐缓存
- 超级岛增加正式权限诊断

重要：小米超级岛正式上岛需要小米焦点通知/超级岛权限。普通第三方 APK 不能仅靠 ADB 或 miui.focus.param 强行绕过 SystemUI 的资格检查。

本包没有刷分区、Root、替换 SystemUI。

构建：使用 Android Studio / Gradle 8.2，模块 app，assembleDebug。
