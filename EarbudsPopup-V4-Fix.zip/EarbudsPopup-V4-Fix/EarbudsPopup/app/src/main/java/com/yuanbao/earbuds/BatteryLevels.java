package com.yuanbao.earbuds;

/**
 * 三方电量数据：左耳 / 右耳 / 充电盒。
 *
 * 关键约定：只有 1~100 才是有效电量。
 * 0 和 -1 都表示「未知」——蓝牙规范里 0 经常代表「未上报」而不是真的没电，
 * 之前把 0 当成有效值填进左右耳，导致弹窗显示 0%，这是最大的一个 bug。
 */
public class BatteryLevels {

    public int left = -1;
    public int right = -1;
    public int caseBox = -1;
    /** 只拿到一个整机值时的兜底 */
    public int overall = -1;
    public long timestamp = 0L;
    /** 数据来源，便于诊断 */
    public String source = "unknown";

    /** 有效电量：1~100。0 与 -1 都视为未知 */
    public static boolean valid(int v) {
        return v >= 1 && v <= 100;
    }

    /** 把无效值统一成 -1，避免 0 流入 UI */
    public static int norm(int v) {
        return valid(v) ? v : -1;
    }

    public boolean anyKnown() {
        return valid(left) || valid(right) || valid(caseBox) || valid(overall);
    }

    /**
     * 兼容旧代码，但故意不再把 overall 复制成左右耳。
     * Android 的 getBatteryLevel()/0x180F 单值只代表“设备/主电量”，
     * 不能证明 L/R 相等。继续复制会把“100% 单值”伪装成 L=100 R=100。
     */
    @Deprecated
    public void fillFromOverall() {
        // no-op by design
    }

    /** 把所有字段里的 0 清成 -1 */
    public void sanitize() {
        left = norm(left);
        right = norm(right);
        caseBox = norm(caseBox);
        overall = norm(overall);
    }

    public static String fmt(int v) {
        return valid(v) ? v + "%" : "--%";
    }
}
